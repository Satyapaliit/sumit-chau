package ConferenceRegistration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationWithWebDriver
{
	public static void main(String[] args)
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\SATYAPKU"
				+ "\\Desktop\\Material\\Module3\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("C:\\NewWorkSpace\\ConferenceRegistration\\HTML Files\\ConferenceRegistartion.html");
		
		try
		{
			driver.findElement(By.id("txtFirstName")).sendKeys("Satyapal");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtLastName")).sendKeys("Kumar");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtEmail")).sendKeys("satyapal@gmail.com");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtPhone")).sendKeys("7618515569");
			Thread.sleep(1000);
			
			
			
			Select dropCount=new Select(driver.findElement(By.name("size")));
			dropCount.selectByVisibleText("3");
			
			driver.findElement(By.id("txtAddress1")).sendKeys("GLC G102");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtAddress2")).sendKeys("Talwade");
			Thread.sleep(1000);

			Select dropCity=new Select(driver.findElement(By.name("city")));
			dropCity.selectByVisibleText("Pune");
			
			Select dropState=new Select(driver.findElement(By.name("state")));
			dropState.selectByVisibleText("Maharashtra");
			
			driver.findElement(By.cssSelector("input[value='member']")).click();
			Thread.sleep(1000);
			
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[14]/td/a")).click();
			Thread.sleep(1000);
			
			driver.switchTo().alert().accept();
			Thread.sleep(1000);
			
			driver.navigate().to("C:\\NewWorkSpace\\ConferenceRegistration\\HTML Files\\PaymentDetails.html");
			
			
			driver.findElement(By.id("txtCardholderName")).sendKeys("Satyapal Kumar");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtDebit")).sendKeys("5896895685478569");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtCvv")).sendKeys("584");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtMonth")).sendKeys("Jan");
			Thread.sleep(1000);
			
			driver.findElement(By.id("txtYear")).sendKeys("2024");
			Thread.sleep(1000);
			
			driver.findElement(By.id("btnPayment")).click();
			Thread.sleep(1000);
			
			driver.switchTo().alert().accept();
			Thread.sleep(1000);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
